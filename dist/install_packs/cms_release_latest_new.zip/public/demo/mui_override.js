﻿
//用户后台自定义文件
// 放置到站点配置目录下即可。
//比如放到站点编号为"1" 的站点,目标路径为"/config/site_1/mui.js"

//window.menuHandler = function (data) {
//    data[0].childs.push({
//        text: '车辆管理2', uri: '', toggle: true, iconPos: '-168|0',
//        childs: [
//            { text: '车辆录入', uri: '/admin/car/AddCarProfile' }
//        ]
//    });
//}