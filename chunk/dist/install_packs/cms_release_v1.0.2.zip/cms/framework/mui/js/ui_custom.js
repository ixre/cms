﻿
//用户后台自定义文件
//window.menuHandler = function (data) {
//    data[0].childs.push({
//        text: '车辆管理2', uri: '', toggle: true, iconPos: '-168|0',
//        childs: [
//            { text: '车辆录入', uri: '/admin/car/AddCarProfile' }
//        ]
//    });
//}

window.menuHandler = function (data) {
    data[0].childs.push(
            {
                text: '<b style="color:green">微信管理</b>',
                uri: '',
                toggle: true,
                iconPos: '-168|0',
                childs: [
                    { text: '基本设置', uri: '/wxm/basicSetting' },
                    { text: '菜单编辑', uri: '/wxm/menu' },
                    { text: '素材管理', uri: '/wxm/resourceList' }
                ]
            });

    data[0].childs.push(
            {
                text: '<b style="color:#ff6600">订单管理</b>',
                uri: '',
                toggle: true,
                iconPos: '-168|0',
                childs: [
                    { text: '所有订单', uri: '/com.easyb2c.h.aspx/admin/orderlist/0/' },
                    { text: '未付款订单', uri: '/com.easyb2c.h.aspx/admin/orderlist/1/' },
                    { text: '已成功订单', uri: '/com.easyb2c.h.aspx/admin/orderlist/5/' },
                    { text: '过期订单', uri: '/com.easyb2c.h.aspx/admin/orderlist/102/' }
                ]
            });

    data[0].childs.push(
            {
                text: '<b style="color:red">订单搜索</b>',
                uri: '',
                toggle: true,
                iconPos: '-168|0',
                childs: [
                    { text: '订单搜索', uri: '/com.easyb2c.h.aspx/admin/ordersearch/' }
                ]
            });

};