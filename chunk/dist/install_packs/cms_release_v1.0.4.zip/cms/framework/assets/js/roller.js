/* 此文件由系统自动生成! */
//
//文件：卷轴插件
//版本: 1.0
//时间：2011-10-01
//

eval(function (p, a, c, k, e, r) { e = function (c) { return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36)) }; if (!''.replace(/^/, String)) { while (c--) r[e(c)] = k[c] || e(c); k = [function (e) { return r[e] } ]; e = function () { return '\\w+' }; c = 1 }; while (c--) if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]); return p } ('$r.s({t:{u:2(a){3.7=a.7;3.n=a.n;3.o=a.o;3.7.4.v+=\'w:x;\'},y:2(a,b){8 c=3.7,5=3.o,a=a|1;8 i,j;8 d;8 e=2(){6(b!=z)b()};A(3.n){9"B":i=5;j=0;d=f(2(){i-=a;6(i<0){i=0;g(d);e()}c.4.p=i.h()+"k"},l);m;9"C":i=5;j=0;d=f(2(){i-=a;6(i<0){i=0;g(d);e()}c.4.q=i.h()+"k"},l);m;9"D":i=0;j=5;d=f(2(){i+=a;6(i>j){i=j;g(d);e()}c.4.p=i.h()+"k"},l);m;9"E":i=0;j=5;d=f(2(){i+=a;6(i>j){i=j;g(d);e()}c.4.q=i.h()+"k"},l);m}}}});', 41, 41, '||function|this|style|_pix|if|elem|var|case||||||setInterval|clearInterval|toString|||px|10|break|direction|pix|height|width|JS|extend|roller|init|cssText|overflow|hidden|start|null|switch|up|left|down|right'.split('|'), 0, {}))