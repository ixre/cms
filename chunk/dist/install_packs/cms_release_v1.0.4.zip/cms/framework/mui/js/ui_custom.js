﻿
//用户后台自定义文件
//window.menuHandler = function (data) {
//    data[0].childs.push({
//        text: '车辆管理2', uri: '', toggle: true, iconPos: '-168|0',
//        childs: [
//            { text: '车辆录入', uri: '/admin/car/AddCarProfile' }
//        ]
//    });
//}